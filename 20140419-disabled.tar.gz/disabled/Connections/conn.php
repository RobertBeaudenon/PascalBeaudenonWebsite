<?php
$hostname_pasc = "localhost";
$database_pasc = "pascalbe_pascalbeaudenon";
$username_pasc = "pascalbe_wiss";
$password_pasc = "wiss";
$conn = mysql_pconnect($hostname_pasc, $username_pasc, $password_pasc) or trigger_error(mysql_error(),E_USER_ERROR); 
?>