<center>
<div style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#636363; text-align:left;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="http://www.pascalbeaudenon.com/pics/logo_pascal_beaudenon_0.gif" border="0"></td>
  </tr>
</table>
<br>
