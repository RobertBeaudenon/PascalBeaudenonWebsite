<?php 
function sendemail4_pascal($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcards1, $postcards2, $textAmount,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr)
{
	$message = getEmailMsg4($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcards1, $postcards2, $textAmount,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);
//echo $message	;
//	$mail = new PHPMailer();
//	$mail->IsHTML(true);
//	$mail->From = "photo@pascalbeaudenon.com";
//	$mail->FromName = "Pascal Beaudenon";
//	$mail->AddAddress("photo@pascalbeaudenon.com");
//	$mail->Subject = "New Unconfirmed Order";
//	$mail->Body = "$message";

	//if(!$mail->Send())
//	{
//	   echo "Message was not sent";
//	   echo "Mailer Error: " . $mail->ErrorInfo;
//	}


		$email = "photo@pascalbeaudenon.com";
		$to = "photo@pascalbeaudenon.com";
	//$mail->Subject = "New Order";
	$message=$message;
	mail($to, "New Unconfirmed Order", $message, "From: $email\nContent-Type: text/html; charset=iso-8859-1");

}
?>
