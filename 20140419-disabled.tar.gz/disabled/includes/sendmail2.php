<?php 
function sendemail2($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr)
{
	$message = getEmailMsg2($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);
//	$mail = new PHPMailer();
//echo $message;
//	$mail->IsHTML(true);
//	$mail->From = "Pascal Beaudenon";
//	$mail->FromName = "Pascal Beaudenon";
//	$mail->AddAddress($user_email);
//	$mail->Subject = "E-mail Confirmation";
//	$mail->Body = "$message";
//
//	if(!$mail->Send())
//	{
//	   echo "Message was not sent";
//	   echo "Mailer Error: " . $mail->ErrorInfo;
//	}
		$email = "photo@pascalbeaudenon.com";
		$to = $user_email;
	
	$message=$message;
	mail($to, "E-mail Confirmation", $message, "From: $email\nContent-Type: text/html; charset=iso-8859-1");
		$email = "photo@pascalbeaudenon.com";
		$to = "photo@pascalbeaudenon.com";
	
	$message=$message;
	//mail($to, "E-mail Confirmation", $message, "From: $email\nContent-Type: text/html; charset=iso-8859-1");
}
?>
