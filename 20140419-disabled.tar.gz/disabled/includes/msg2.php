<?php 
function getEmailMsg2($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr)
{
	
	global $HTTP_POST_VARS;
	ob_start();
	
include("email_header.php"); ?>

<div style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#636363">
Dear <span style="font-size:13px; font-weight:bold"><?php echo $user_name; ?></span>,<br />

Thank you for purchasing online "The Other Lebanon" products.<br />
Unfortunately, your transaction was refused. One of the following errors has occurred:<br /> 
<ul>
<li>Invalid card number entered. Please try again.</li>
<li>Invalid expiry date entered. This must be a date in the future. Please try again. </li>
<li>Invalid Security Code. Please try again.</li>
</ul>
Regards,<br />
<strong>Pascal Beaudenon.</strong>

</div>

<?php include("email_footer.php");

	$msg = ob_get_contents();
	ob_end_clean();
	return ($msg);
}
?>
