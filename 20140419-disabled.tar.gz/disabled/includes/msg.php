<?php 
function getEmailMsg($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $textAmount,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr)
{
	
	global $HTTP_POST_VARS;
	ob_start();
	
include("email_header.php"); ?>

<div style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#636363">
Dear <span style="font-size:13px; font-weight:bold"><?php echo $user_name; ?></span>,<br />
Thank you for purchasing "The Other Lebanon" product online.<br />Your transaction was accepted. Kindly find below the details of your order:<br /><br />


Order details:
<table border="0" cellpadding="3" cellspacing="1" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#636363">
  <tr>
    <td width="160" align="left" valign="top" bgcolor="#D7E3F1"><strong>The Other Lebanon: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $tol; ?> item(s)
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#D7E3F1"><strong>2006 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $calendar2006; ?> item(s)

	</td>
  </tr>
 
  <tr>
    <td align="left" valign="top" bgcolor="#D7E3F1"><strong>2009 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $calendar2009; ?> item(s)
	<br />
<?php echo $calendar2009_eng; ?> English<br /><?php echo $calendar2009_fr; ?> French
	</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#D7E3F1"><strong>Postcards - Set 1: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $postcard1; ?> item(s)

	</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#D7E3F1"><strong>Postcards - Set 2:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $postcard2; ?> item(s)

	</td>
  </tr>
</table>
<br />
<table border="0" cellpadding="3" cellspacing="1" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#636363; font-weight:bold">
  <tr>
    <td width="160" align="left" bgcolor="#D7E3F1" style="padding-left:4px;"><strong>TOTAL </strong></td>
    <td bgcolor="#D7E3F1"><strong><?php echo $textAmount; ?> USD</strong></td>
  </tr>
</table><br />
Your order will be dispatched tomorrow morning and will be delivered to you in three to five working days. <br />
<!--Please note that if you've ordered the 2009 calendar, it will be delivered to you by November 25, 2008.<br />
 -->Should you have any inquiry, do contact us at <a href="mailto:photo@pascalbeaudenon.com">photo@pascalbeaudenon.com</a>
<br /><br />

With all best wishes<br /><br />
 
<strong>The team of The Other Lebanon</strong><br />
<br />
<br />
______________________________________________________________________
<br />
<br />
<br />
Cher/Ch&egrave;re <span style="font-size:13px; font-weight:bold"><?php echo $user_name ?></span>,<br />
Merci de votre commande en ligne des produits de L'Autre Liban. Votre paiement a &eacute;t&eacute; accept&eacute;.<br />
Veuillez trouver ci-dessous les d&eacute;tails de votre commande:
<br /><br />


<table border="0" cellpadding="3" cellspacing="1" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#636363">
  <tr>
    <td width="160" align="left" bgcolor="#D7E3F1"><strong>The Other Lebanon: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $tol; ?> item(s)</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Calendrier 2006:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $calendar2006; ?> item(s)</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Calendrier 2007:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $calendar2007; ?> item(s)</td>
  </tr>
    <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Calendrier 2008:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $calendar2008; ?> item(s)</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Postcards - Set 1: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $postcard1; ?> item(s)</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Postcards - Set 2:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $postcard2; ?> item(s)</td>
  </tr>
</table>
<br />
<table border="0" cellpadding="3" cellspacing="1" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#636363; font-weight:bold">
  <tr>
    <td width="160" align="left" bgcolor="#D7E3F1" style="padding-left:4px;"><strong>TOTAL </strong></td>
    <td bgcolor="#D7E3F1"><strong><?php echo $textAmount; ?> USD</strong></td>
  </tr>
</table><br />
Votre commande sera envoy&eacute;e demain matin et vous sera livr&eacute;e en trois &agrave; cinq jours ouvrables.<br />
Pour toute information sur votre commande ou sur L'Autre Liban, n'h&eacute;sitez pas &agrave; nous contacter par mail &agrave; <a href="mailto:photo@pascalbeaudenon.com">photo@pascalbeaudenon.com</a>

<br /><br />

Amicalement<br /><br />
 
<strong>L'&eacute;quipe de l'Autre Liban </strong>









</div>



<?php include("email_footer.php");

	$msg = ob_get_contents();
	ob_end_clean();
	return ($msg);
}
?>
