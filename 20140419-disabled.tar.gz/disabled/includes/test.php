<?php
include "sendmail4.php";
include"msg4.php";
include"class.phpmailer.php";
 sendemail4_pascal('user_name', 'user_email', 'tol', 'calendar2006', 'calendar2007', 'calendar2008', 'calendar2009', 'postcards1', 'postcards2', 'textAmount','book_01_eng','book_01_fr','calendar2009_fr','calendar2009_eng','calendar2006_eng','calendar2006_fr','post1_eng','post1_fr','post2_eng','post2_fr');?>