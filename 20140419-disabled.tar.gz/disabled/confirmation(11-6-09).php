<?php
require_once('Connections/conn.php');
mysql_select_db($database_pasc, $conn);

require("includes/class.phpmailer.php");
require("includes/sendmail.php");
require("includes/sendmail2.php");
require("includes/sendmail3.php");
require("includes/sendmail4.php");
require("includes/msg.php");
require("includes/msg2.php");
require("includes/msg3.php");
require("includes/msg4.php");


$RespVal = $HTTP_POST_VARS["RespVal"];
$RespMsg = $HTTP_POST_VARS["RespMsg"];
$txtIndex = $HTTP_POST_VARS["txtIndex"];
$txtMerchNum = $HTTP_POST_VARS["txtMerchNum"];
$txtNumAut = $HTTP_POST_VARS["txtNumAut"];
$txtAmount = $HTTP_POST_VARS["txtAmount"];
$signature = $HTTP_POST_VARS["signature"];



$refused = "Transaction refused";
$authorized = "Transaction authorized";

/*
echo "RespVal: ". $RespVal . "<br>";
echo "RespMsg: ". $RespMsg . "<br>";
echo "txtIndex: ". $txtIndex . "<br>";
echo "txtMerchNum: ". $txtMerchNum . "<br>";
echo "txtNumAut: ". $txtNumAut . "<br>";
echo "txtAmount: ". $txtAmount . "<br>";
echo "signature: ". $signature . "<br>";
*/


$sqlseluser = "SELECT * FROM users WHERE order_id='$txtIndex'";
//echo $sqlseluser;
$sqlselrun = mysql_query($sqlseluser,$conn);
$result = mysql_fetch_array($sqlselrun);


$user_name = $result["user_name"];
$user_email = $result["user_email"];
$tol = $result["user_tol"];
$calendar2006 = $result["user_calendar2006"];
$calendar2007 = $result["user_calendar2007"];
$calendar2008 = $result["user_calendar2008"];
$calendar2009 = $result["user_calendar2009"];
$postcard1 = $result["user_postcard1"];
$postcard2 = $result["user_postcard2"];
$bill = $result["user_bill"];
//$txtAmount = $result["user_bill"];

$book_01_eng=$_POST["book_01_eng"];
$book_01_fr=$_POST["book_01_fr"];
$calendar2009_fr=$result["calendar2009_fr"];
$calendar2009_eng=$result["calendar2009_eng"];
$calendar2006_eng=$result["calendar2006_eng"];
$calendar2006_fr=$result["calendar2006_fr"];
$post1_eng=$result["post1_eng"];
$post1_fr=$result["post1_fr"];
$post2_eng=$result["post2_eng"];
$post2_fr=$result["post2_fr"];

$sqluser = "SELECT * FROM users WHERE order_id='$txtIndex'";
$sqlr = mysql_query($sqluser);
$resr = mysql_fetch_array($sqlr);
$id = $resr["user_id"];


if($RespVal=="0") {
$sqlupdate="UPDATE users SET confirmation='$refused' WHERE order_id='$txtIndex'"; 
mysql_query($sqlupdate);

$msg = "Unfortunately, your transaction was refused. One of the following errors has occurred:<br> 
<ul>
<li>Invalid card number entered. Please try again.</li>
<li>Invalid expiry date entered. This must be a date in the future. Please try again. </li>
<li>Invalid Security Code. Please try again.</li>
</ul>";
//echo $msg;
sendemail2($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);
sendemail4_pascal($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcard1, $postcard2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);


}
if($RespVal=="1") {
$sqlupdate="UPDATE users SET confirmation='$authorized' WHERE order_id='$txtIndex'"; 
mysql_query($sqlupdate);

$msg = "Thank you for purchasing The Other Lebanon products online.<br>
Your transaction was accepted. Your order will be dispatched tomorrow morning and will be delivered to you in three to five working days. <br>
Please note that if you've ordered the 2009 calendar, it will be delivered to you by November 25, 2008.<br>
Should you have any inquiry, do contact us at photo@pascalbeaudenon.com
<br>
<br>
<br>

Merci de votre commande en ligne des produits de L'Autre Liban.<br>
Votre paiement a �t� accept�. Votre commande sera envoy�e demain matin et vous sera livr�e en trois � cinq jours ouvrables.<br>
Si vous avez command� le calendrier 2009, notez qu'il vous sera livr� � sa parution avant le 25 Novembre 2008.<br>
Pour toute information sur votre commande ou sur L'Autre Liban, n'h�sitez pas � nous contacter par mail � photo@pascalbeaudenon.com";


sendemail($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcards1, $postcards2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);
sendemail_pascal($id,$user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcards1, $postcards2, $bill,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Pascal Beaudenon - Landscape Photographies of Lebanon</title>
<meta name="description" content="Official website of landscape photographer Pascal Beaudenon. Panoramic photographies from all over Lebanon.">
<meta name="keywords" content="beaudenon,pascalbeaudenon,pascal beaudenon,landscape photography,landscape photographer,photo,photos,photographies,photographe,lebanon,photos lebanon,lebanon photos,liban,photos liban,liban photos,photographie panoramique,photo panoramique,photos panoramiques">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" CONTENT="en,fr">
<meta name="robots" content="index,follow">
<meta name="author" content="Powered by ZWYX.org">
<meta name="copyright" content="copyright (c) www.pascalbeaudenon.com">
<link href="css/main.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="js/main.js"></script>
<script language="JavaScript" src="js/formail_check.js"></script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="t12" align="right"><a href="contact.html" class="link_menu"><b>CONTACT</b></a></td>
</tr>
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="bottom"> 
    <td width="470" class="t12"><a href="photos_album2.html" class="link_menu"><strong>PHOTOGRAPHIES</strong></a> 
      <strong>&nbsp;-&nbsp; <a href="publications_lebanon1_map.html" class="link_menu">THE BOOK</a> &nbsp;-&nbsp; <a href="publications.html" class="link_menu"><font color="#FF0000">PUBLICATIONS</font></a> &nbsp;-&nbsp; <a href="exhibitons.html" class="link_menu">EXHIBITIONS</a> &nbsp;-&nbsp; <a href="info.html" class="link_menu">INFO</a> &nbsp;-&nbsp; <a href="order2.php" class="link_menu">ORDER</a></strong></td>
    <td width="180" align="right"><a href=""><img src="pics/logo_pascal_beaudenon_0.gif" alt="Pascal Beaudenon - landscape photographies - photographies panoramiques" width="160" height="20" border="0"></a></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t13">P u b l i c a t i o n s</td>
    <td width="270">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><strong>The Other Lebanon | <em>L'Autre Liban</em></strong> - <span class="t10">publication: 
      dec. 2005 </span><br>
      <br>
      <table border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="t12"><strong><a href="publications_lebanon1_forword.html">Forword</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="photos_album2.html">Photos</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_lebanon1_map.html">The 
            Book</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="publications_calendar2009.html"><strong class="Blue">Calendar 
            2009</strong></a></td>
		   <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="other-calendars.html"><strong>Other Products</strong></a></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_postcards.html">Postcards</a></strong></td>
         
          
        </tr>
        <tr> 
          <td class="t12"><img src="pics/pixel.gif" width="1" height="4"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td class="t12"><em><a href="publications_lebanon1_forword.html">Pr&eacute;face</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="photos_album2.html">Photos</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="publications_lebanon1_map.html">Le Livre</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="publications_calendar2009.html"><span class="Blue">Calendrier 
            2009</span></a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="other-calendars.html">Autres Produits</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><em><a href="publications_postcards.html">Cartes Postales</a></em></td>
          
          
        </tr>
      </table> </td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>
<?php echo $msg?><br>

</td>
</tr></table>
<br>
<br>
<table width="100" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<table width="651" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t10">&copy; pascal beaudenon, 2005</td>
    <td width="271" align="right" class="t10">&nbsp;</td>
  </tr>
</table>
<br>
<br>
</body>
</html>
