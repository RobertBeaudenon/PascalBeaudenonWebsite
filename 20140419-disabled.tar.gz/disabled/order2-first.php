<?php require_once('Connections/conn.php');?>
<html>
<head>
<title>Pascal Beaudenon - Landscape Photographies of Lebanon</title>
<meta name="description" content="Official website of landscape photographer Pascal Beaudenon. Panoramic photographies from all over Lebanon.">
<meta name="keywords" content="beaudenon,pascalbeaudenon,pascal beaudenon,landscape photography,landscape photographer,photo,photos,photographies,photographe,lebanon,photos lebanon,lebanon photos,liban,photos liban,liban photos,photographie panoramique,photo panoramique,photos panoramiques">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" CONTENT="en,fr">
<meta name="robots" content="index,follow">
<meta name="author" content="Powered by ZWYX.org">
<meta name="copyright" content="copyright (c) www.pascalbeaudenon.com">
<link href="css/main.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="js/main.js"></script>
<script language="JavaScript" src="js/formail_check.js"></script>

<script language="javascript">




var shipping_book_prices      = [34, 53, 79, 105, 131, 157];
var shipping_calendar_prices  = [6, 9, 13, 16, 20];
var shipping_postcards_prices = [4, 4, 4, 4, 7, 7, 7, 7, 9, 9, 9, 9];


function clean(fld)
{
	if(!isNaN(parseInt(fld.value))){
		fld.value = parseInt(fld.value);
		return parseInt(fld.value);
	}
	fld.value = 0;
	return 0;
}
function myRound(totalnum)
{
//var totalnum = "2345.678";
	totalnum = new String(totalnum);
	if(totalnum.indexOf(".") != -1){
		var mystring = totalnum.indexOf(".")+3;
	} else {
		var mystring = totalnum;
	}
	var finalnum = totalnum.substr(0, mystring);
	return (finalnum);
}

function checkTotal()
{
	if(document.form1.totalnum.value != "")
	{
		document.form1.submit();
	}
	else { 
	alert("Please make an order"); 
	document.MM_returnValue = false;
	}
}
function zeroMe(fld)
{
	if(isNaN(parseInt(fld.value))){
		fld.value = 0;
	}
}

//-- type may be: book, calendar, postcards
function calculateShipping(type, qnty)
{
	var qnty = parseInt(qnty);
	if(qnty < 1) return 0;
	
	var arr = eval("shipping_"+type+"_prices");
	return arr[qnty-1];
}

function calculate()
{
	var max_books = 6;
	var max_calendar = 5;
	var max_postcards = 12;
	
	var field1 = clean(document.form1.book_01);
	var field2 = clean(document.form1.calendar2007);
	var field5 = clean(document.form1.calendar2006);
	var field6 = clean(document.form1.calendar2008);
	var field3 = clean(document.form1.postcards1);
	var field4 = clean(document.form1.postcards2);
	
	// check if the quantity is more than 6
	if(parseInt(field1) > max_books){
		alert("To order 7 or more books, please email us ");
		document.form1.book_01.value = max_books;
		field1 = max_books;
	}
	if(parseInt(field2) > max_calendar){
		alert("To order 6 or more calendars, please email us ");
		document.form1.calendar2007.value = max_calendar;
		field2 = max_calendar;
	}
	if(parseInt(field5) > max_calendar){
		alert("To order 6 or more calendars, please email us ");
		document.form1.calendar2006.value = max_calendar;
		field5 = max_calendar;
	}
	if(parseInt(field6) > max_calendar){
		alert("To order 6 or more calendars, please email us ");
		document.form1.calendar2008.value = max_calendar;
		field6 = max_calendar;
	}
	if(parseInt(field3) > max_postcards){
		alert("To order 13 or more postcards, please email us ");
		document.form1.postcards1.value = max_postcards;
		field3 = max_postcards;
	}
	if(parseInt(field4) > max_postcards){
		alert("To order 13 or more postcards, please email us ");
		document.form1.postcards2.value = max_postcards;
		field4 = max_postcards;
	}
	
	
	// get shipping fees on books
	var books_fees = calculateShipping("book", field1);
	var calendar_fees = calculateShipping("calendar", field2);
	var calendar2006_fees = calculateShipping("calendar", field5);
	var calendar2008_fees = calculateShipping("calendar", field6);
	var postcards1_fees = calculateShipping("postcards", field3);
	var postcards2_fees = calculateShipping("postcards", field4);
		
	var first_fee = books_fees;
	var second_fee = calendar_fees;
	var third_fee = postcards1_fees;
	var fourth_fee = postcards2_fees;
	var fifth_fee = calendar2006_fees;
	var six_fee = calendar2008_fees;
	
	var first_price = field1*95;
	var second_price = field2*12;
	var third_price = field3*8;
	var fourth_price = field4*8;
	var fifth_price = field5*12;
	var six_price = field6*17;
	
	var first = first_price + first_fee;
	var second = second_price + second_fee;
	var third = third_price + third_fee;
	var fourth = fourth_price + fourth_fee;
	var fifth = fifth_price + fifth_fee;
	var six = six_price + six_fee;
	
	
	var total_fees = first_fee + second_fee + third_fee + fourth_fee + fifth_fee + six_fee;
	var prototal = first_price + second_price + third_price + fourth_price + fifth_price + six_price;
	var total = first + second + third + fourth + fifth + six;
	
	document.form1.book_price.value = myRound(first_price);
	document.form1.book_fees.value = myRound(first_fee);
	document.form1.calendar_price.value = myRound(second_price);
	document.form1.calendar_fees.value = myRound(second_fee);
	document.form1.calendar2006_price.value = myRound(fifth_price);
	document.form1.calendar2006_fees.value = myRound(fifth_fee);
	document.form1.calendar2008_price.value = myRound(six_price);
	document.form1.calendar2008_fees.value = myRound(six_fee);
	document.form1.post1_price.value = myRound(third_price);
	document.form1.post1_fees.value = myRound(third_fee);
	document.form1.post2_price.value = myRound(fourth_price);
	document.form1.post2_fees.value = myRound(fourth_fee);
	document.form1.totalnum.value = myRound(total);
	document.form1.fees.value = myRound(total_fees);
	document.form1.prototal.value = myRound(prototal);
	zeroMe(document.form1.book_price);
	zeroMe(document.form1.book_fees);
	zeroMe(document.form1.calendar_price);
	zeroMe(document.form1.calendar_fees);
	zeroMe(document.form1.calendar2006_price);
	zeroMe(document.form1.calendar2006_fees);
	zeroMe(document.form1.calendar2008_price);
	zeroMe(document.form1.calendar2008_fees);
	zeroMe(document.form1.post1_price);
	zeroMe(document.form1.post2_price);
	zeroMe(document.form1.post1_fees);
	zeroMe(document.form1.post2_fees);
	
}

function checkfld(fld)
	{
		if(fld.value == "0" || fld.value == ""){
			fld.value = "";
		}
		fld.onblur = function()
		{
			if(isNaN(parseInt(this.value))){
				this.value = "0";
			}
		}
	}
</script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="t12" align="right"><a href="contact.html" class="link_menu"><b>CONTACT</b></a></td>
</tr>
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="bottom"> 
    <td width="470" class="t12"><a href="photos_album2.html" class="link_menu"><strong>PHOTOGRAPHIES</strong></a> 
      <strong>&nbsp;-&nbsp; <a href="publications" class="link_menu">THE BOOK</a>&nbsp;-&nbsp; <a href="publications_calendar2009.html" class="link_menu">PUBLICATIONS</a> 
      &nbsp;-&nbsp; <a href="exhibitons.html" class="link_menu">EXHIBITIONS</a> 
      &nbsp;-&nbsp; <a href="info.html" class="link_menu">INFO</a> &nbsp;-&nbsp; 
      <a href="order2.php" class="link_menu" ><font color="#FF0000">ORDER</font></a></strong></td>
    <td width="180" align="right"><img src="pics/logo_pascal_beaudenon_0.gif" alt="Pascal Beaudenon - panorama landscape photographies of Lebanon - photographies panoramiques du Liban" width="160" height="20"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t13">P u b l i c a t i o n s</td>
    <td width="270">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><strong>The Other Lebanon | <em>L'Autre Liban</em></strong> - <span class="t10">publication: 
      dec. 2005 </span><br>
      <br>
      <table border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="t12"><strong><a href="publications_lebanon1_forword.html">Forword</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="photos_album2.html">Photos</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_lebanon1_map.html">The 
            Book</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="publications_calendar2009.html"><strong class="Blue">Calendar 
            2009</strong></a></td>
		   <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="other-calendars.html"><strong>Other Products</strong></a></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_postcards.html">Postcards</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><font color="#CC6600">How to buy</font></strong></td>
        </tr>
        <tr> 
          <td class="t12"><img src="pics/pixel.gif" width="1" height="4"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td class="t12"><em><a href="publications_lebanon1_forword.html">Pr&eacute;face</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="photos_album2.html">Photos</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="publications_lebanon1_map.html">Le Livre</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="publications_calendar2009.html"><span class="Blue">Calendrier 
            2009</span></a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="other-calendars.html">Autres Produits</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><em><a href="publications_postcards.html">Cartes Postales</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><em><font color="#CC6600">Acheter?</font></em></td>
        </tr>
      </table> </td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="305" valign="top" class="t12"><div align="justify">to order online, please select the quantity of each item by filling the form below:</div></td>
    <td width="40" class="t12">&nbsp;</td>
    <td width="305" valign="top" class="t12"><div align="justify"> <em>Pour commander 
        en ligne, veuillez fixer la quantit&eacute; de chaque article et remplir le formulaire ci-dessous:</em></div></td>
  </tr>
</table>
<br>
<form action="order3.php" name="form1" method="post" onSubmit="checkTotal();return document.MM_returnValue">

<input type=hidden name="subject" value="pascalbeaudenon.com - contact form">
<input type=hidden name="env_report" value="REMOTE_HOST,HTTP_USER_AGENT,REMOTE_USER,REMOTE_ADDR,HTTP_REFERER">
<input type=hidden name="redirect" value="http://www.pascalbeaudenon.com/order_bravo.html">

  <table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td colspan="2" style="font-size:11px; color:#002AA1; padding-bottom:10px"></td>
      <td width="320" valign="top" style="font-size:11px; color:#002AA1"></td>
    </tr>
    <tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>The Other Lebanon</strong><div style="font-size:10px; color:#002AA1">Available Now</div></td>
	  <td valign="top" bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>L'Autre 
        Liban</em></font></strong><div style="font-size:10px; color:#002AA1">Disponible</div></td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">
	&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="book_01" type="text" id="book_01" value="0" onChange="javascript:calculate()" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="book_price" type="text" id="book_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="book_fees" type="text" id="book_fees" value="0" readonly="" size="2"></td>
  </tr>
</table>	  </td>
    </tr>
    <tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>2006 Calendar</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
        2006</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2006" type="text" id="calendar2006" onChange="javascript:calculate()" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar2006_price" type="text" id="calendar2006_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="calendar2006_fees" type="text" id="calendar2006_fees" value="0" readonly="" size="2"></td>
  </tr>
</table>	  </td>
    </tr>
	 <tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>2007 Calendar</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
	  <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
       2007</em></font></strong><div style="font-size:10px;">disponible</div></td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2007" type="text" id="calendar2007" onChange="javascript:calculate()" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar_price" type="text" id="calendar_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="calendar_fees" type="text" id="calendar_fees" value="0" readonly="" size="2"></td>
  </tr>
</table>	  </td>
    </tr>
	
	
	
	<tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>2008 Calendar</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
	  <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
       2008</em></font></strong><div style="font-size:10px;">disponible</div></td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2008" type="text" id="calendar2008" onChange="javascript:calculate()" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar2008_price" type="text" id="calendar2008_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="calendar2008_fees" type="text" id="calendar2008_fees" value="0" readonly="" size="2"></td>
  </tr>
</table>	  </td>
    </tr>
	
	
	
    <tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>Postcards - set 1 </strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Cartes 
        Postales - s&eacute;rie 1</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="postcards1" type="text" id="postcards1" value="0" onChange="javascript:calculate()" size="2"></td>
	<td class="t12">&nbsp;price&nbsp;<input name="post1_price" type="text" id="post1_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="post1_fees" type="text" id="post1_fees" value="0" readonly="" size="2"></td>
	</tr>
	</table>	</td>
    </tr>
    <tr> 
      <td bgcolor="#EEEEEE" class="t12"><strong>Postcards - set 2</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Cartes 
        Postales - s&eacute;rie 2</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td align="right" valign="top" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="postcards2" type="text" id="postcards2" value="0" onChange="javascript:calculate()" size="2"></td>
	<td class="t12">&nbsp;price&nbsp;<input name="post2_price" type="text" id="post2_price" value="0" readonly="" size="2"></td>
    <td class="t12">&nbsp;Shipping fees&nbsp;<input name="post2_fees" type="text" id="post2_fees" value="0" readonly="" size="2"></td>
	</tr>
	</table>	</td>
    </tr>
    
	<tr><td>&nbsp;</td>
	<td align="right" class="t12" style="padding-top:10px;">Products amount  <strong>$</strong> <input value="" name="prototal" type="text" size="8" readonly="readonly" style="font-weight:bold; font-size:12px; text-align:center;"></td></tr>
	<tr><td>&nbsp;</td>
	<td align="right" class="t12">Shipping fees  <strong>$</strong> <input value="" name="fees" type="text" size="8" readonly="readonly" style="font-weight:bold; font-size:12px; text-align:center;"></td></tr>
	 <tr> 
      <td align="right" colspan="2" class="t12">Total: <strong>$</strong>
       <input name="totalnum" type="text" value="" size="8" readonly="true" style="font-weight:bold; font-size:12px; text-align:center;"></td>
      <td valign="top" class="t12"> &nbsp; <input name="total" type="button" onClick="javascript:calculate()" value="Calculate"></td>
    </tr>
	<tr><td colspan="3"><div align="center">
  <br>
  <input name="total2" type="hidden" value="<?php echo $total;?>">
   <input name="continue" value="Continue" type="submit"></div></td></tr>
	
	<tr> 
      <td style="font-size:11px;padding-top:10px; padding-bottom:10px" colspan="3" class="t12">
	  You can cut the photographs in calendars 2006 and 2007 and frame them into beautiful posters<br>
	  <em>Vous pouvez couper les photos des calendriers 2006 et 2007 pour les encadrer</em><br><br>
	  To order 6 or more calendars, please <a href="mailto:photo@pascalbeaudenon.com">email us</a><br>
	  <em>Pour une commande de plus de 6 calendriers, veuillez <a href="mailto:photo@pascalbeaudenon.com">nous contacter</a></em><br>
<br>

Note that the shipping fee is the same for the order of 1 to 4 sets of postcards as well as from 5 to 8 and from 9 to 12.<br>
<em>Notez que le prix de livraison est le m&ecirc;me pour une commande de 1 &agrave; 4 jeux de cartes postales ainsi que de 5 &agrave; 8 et de 9 &agrave; 12</em><br>
<br>


	  to order 7 or more Books, please <a href="mailto:photo@pascalbeaudenon.com">email us</a><br>
	  <em>Pour une commande de plus de 7 livres, veuillez <a href="mailto:photo@pascalbeaudenon.com">nous contacter</a></em><br>
<br>

	  
	  All shipment will be made via express courrier (with delivery made in three to five working days)</td>
    </tr>
  </table>

  
</form>


<table width="100" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="http://www.netcommerce.com.lb/logo/epayment-netcommerce.gif" width="400"
height="38" border="0" alt="E-Payment By Netcommerce"><br><br></td>
  </tr>
</table>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<table width="651" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t10">&copy; pascal beaudenon, 2005</td>
    <td width="271" align="right" class="t10">&nbsp;</td>
  </tr>
</table>
<br>
<br>
</body>
</html>