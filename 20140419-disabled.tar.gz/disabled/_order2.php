<?php require_once('Connections/conn.php');?>
<html>
<head>
<title>Pascal Beaudenon - Landscape Photographies of Lebanon</title>
<meta name="description" content="Official website of landscape photographer Pascal Beaudenon. Panoramic photographies from all over Lebanon.">
<meta name="keywords" content="beaudenon,pascalbeaudenon,pascal beaudenon,landscape photography,landscape photographer,photo,photos,photographies,photographe,lebanon,photos lebanon,lebanon photos,liban,photos liban,liban photos,photographie panoramique,photo panoramique,photos panoramiques">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" CONTENT="en,fr">
<meta name="robots" content="index,follow">
<meta name="author" content="Powered by ZWYX.org">
<meta name="copyright" content="copyright (c) www.pascalbeaudenon.com">
<link href="css/main.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="js/main.js"></script>
<script language="JavaScript" src="js/formail_check.js"></script>

<script language="javascript">




var shipping_book_prices      = [34, 53, 79, 105, 131, 157];
var shipping_calendar_prices  = [6, 9, 13, 16, 20];
var shipping_postcards_prices = [4, 4, 4, 4, 7, 7, 7, 7, 9, 9, 9, 9];


function clean(fld)
{
	if(!isNaN(parseInt(fld.value))){
		fld.value = parseInt(fld.value);
		return parseInt(fld.value);
	}
	fld.value = 0;
	return 0;
}
function myRound(totalnum)
{
//var totalnum = "2345.678";
	totalnum = new String(totalnum);
	if(totalnum.indexOf(".") != -1){
		var mystring = totalnum.indexOf(".")+3;
	} else {
		var mystring = totalnum;
	}
	var finalnum = totalnum.substr(0, mystring);
	return (finalnum);
}

function checkTotal()
{
	if(document.form1.totalnum.value != "")
	{
		document.form1.submit();
	}
	else { 
	alert("Please make an order"); 
	document.MM_returnValue = false;
	}
}
function zeroMe(fld)
{
	if(isNaN(parseInt(fld.value))){
		fld.value = 0;
	}
}

//-- type may be: book, calendar, postcards
function calculateShipping(type, qnty)
{
	var qnty = parseInt(qnty);
	if(qnty < 1) return 0;
	
	var arr = eval("shipping_"+type+"_prices");
	return arr[qnty-1];
}


function calculate(fld)
{
	var last_fld = "";
	if(typeof fld != "undefined") last_fld = fld;
	
	var max_books = 6;
	var max_calendar = 5;
	var max_postcards = 12;
	
	var field1 = clean(document.form1.book_01);
	var field2 = clean(document.form1.calendar2007);
	var field5 = clean(document.form1.calendar2006);
	var field6 = clean(document.form1.calendar2008);
	var field3 = clean(document.form1.postcards1);
	var field4 = clean(document.form1.postcards2);
	
	// check if the quantity is more than 6
	if(parseInt(field1) > max_books){
		alert("To order 7 or more books, please email us ");
		document.form1.book_01.value = max_books;
		field1 = max_books;
	}
	
	field2 = parseInt(field2);
	field5 = parseInt(field5);
	field6 = parseInt(field6);
	var more_calendars = false;
	var more_postcards = false;
	
	if(field2+field5+field6 > max_calendar){
		more_calendars = true;
		if(last_fld == document.form1.calendar2007){
			var rem = max_calendar - (field5+field6);
			document.form1.calendar2007.value = rem;
			field2 = rem;
		}
	}
	if(field2+field5+field6 > max_calendar){
		more_calendars = true;
		if(last_fld == document.form1.calendar2006){
			var rem = max_calendar - (field2+field6);
			document.form1.calendar2006.value = rem;
			field5 = rem;
		}
	}
	if(field2+field5+field6 > max_calendar){
		more_calendars = true;
		if(last_fld == document.form1.calendar2008){
			var rem = max_calendar - (field2+field5);
			document.form1.calendar2008.value = rem;
			field6 = rem;
		}
	}
	if(more_calendars){
		alert("To order 6 or more calendars, please email us ");
	}
	
	field3 = parseInt(field3);
	field4 = parseInt(field4);
	
	if(field3+field4 > max_postcards){
		more_postcards = true;
		if(last_fld == document.form1.postcards1){
			document.form1.postcards1.value = max_postcards - (field4);
			field3 = max_postcards - (field4);
		}
	}
	if(field3+field4 > max_postcards){
		more_postcards = true;
		if(last_fld == document.form1.postcards2){
			document.form1.postcards2.value = max_postcards - (field3);
			field4 = max_postcards - (field3);
		}
	}
	if(more_postcards){
		alert("To order 13 or more postcards, please email us ");
	}
	
	var total_calendars = field2 + field5 + field6;
	var total_postcards = field3 + field4;
	
	// get shipping fees on books
	var books_fees =     calculateShipping("book", field1);
	var calendar_fees =  calculateShipping("calendar", total_calendars);
	var postcards_fees = calculateShipping("postcards", total_postcards);
	
	var first_price = field1*95;
	var second_price = field2*12;
	var third_price = field3*8;
	var fourth_price = field4*8;
	var fifth_price = field5*12;
	var six_price = field6*17;	
	
	var total_fees = books_fees + calendar_fees + postcards_fees;
	var prototal   = first_price + second_price + third_price + fourth_price + fifth_price + six_price;
	var total      = first_price + second_price + third_price + fourth_price + fifth_price + six_price + books_fees + calendar_fees + postcards_fees;
	
	document.form1.book_price.value = myRound(first_price);
	document.form1.book_fees.value = myRound(books_fees);
	document.form1.calendar_price.value = myRound(second_price);
	document.form1.calendar2006_price.value = myRound(fifth_price);
	document.form1.calendar2008_price.value = myRound(six_price);
	document.form1.calendar_fees.value = myRound(calendar_fees);
	document.form1.post1_price.value = myRound(third_price);
	document.form1.post2_price.value = myRound(fourth_price);
	document.form1.post1_fees.value = myRound(postcards_fees);
	document.form1.totalnum.value = myRound(total);
	document.form1.fees.value = myRound(total_fees);
	document.form1.prototal.value = myRound(prototal);
	zeroMe(document.form1.book_price);
	zeroMe(document.form1.book_fees);
	zeroMe(document.form1.calendar_price);
	zeroMe(document.form1.calendar2006_price);
	zeroMe(document.form1.calendar2008_price);
	zeroMe(document.form1.calendar_fees);
	zeroMe(document.form1.post1_price);
	zeroMe(document.form1.post2_price);
	zeroMe(document.form1.post_fees);
	
}

function checkfld(fld)
	{
		if(fld.value == "0" || fld.value == ""){
			fld.value = "";
		}
		fld.onblur = function()
		{
			if(isNaN(parseInt(this.value))){
				this.value = "0";
			}
		}
	}
</script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="t12" align="right"><a href="contact.html" class="link_menu"><b>CONTACT</b></a></td>
</tr>
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="bottom"> 
    <td width="470" class="t12"><a href="photos_album2.html" class="link_menu"><strong>PHOTOGRAPHIES</strong></a> 
      <strong>&nbsp;-&nbsp; <a href="publications_lebanon1_map.html" class="link_menu">THE BOOK</a>&nbsp;-&nbsp; <a href="publications.html" class="link_menu">PUBLICATIONS</a> 
      &nbsp;-&nbsp; <a href="exhibitons.html" class="link_menu">EXHIBITIONS</a> 
      &nbsp;-&nbsp; <a href="info.html" class="link_menu">INFO</a> &nbsp;-&nbsp; 
      <a href="order2.php" class="link_menu" ><font color="#FF0000">ORDER</font></a></strong></td>
    <td width="180" align="right"><img src="pics/logo_pascal_beaudenon_0.gif" alt="Pascal Beaudenon - panorama landscape photographies of Lebanon - photographies panoramiques du Liban" width="160" height="20"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t13">P u b l i c a t i o n s</td>
    <td width="270">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><strong>The Other Lebanon | <em>L'Autre Liban</em></strong> - <span class="t10">publication: 
      dec. 2005 </span><br>
      <br>
      <table border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="t12"><strong><a href="publications_lebanon1_forword.html">Forword</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="photos_album2.html">Photos</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_lebanon1_map.html">The 
            Book</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="publications_calendar2008.html"><strong>Calendar 
            2008</strong></a></td>
		   <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="other-calendars.html"><strong>Other Calendars</strong></a></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_postcards.html">Postcards</a></strong></td>
         
        </tr>
        <tr> 
          <td class="t12"><img src="pics/pixel.gif" width="1" height="4"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td class="t12"><em><a href="publications_lebanon1_forword.html">Pr&eacute;face</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="photos_album2.html">Photos</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="publications_lebanon1_map.html">Le Livre</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="publications_calendar2008.html">Calendrier 
            2008</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="other-calendars.html">Autres Calendriers</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><em><a href="publications_postcards.html">Cartes Postales</a></em></td>
          
        </tr>
      </table> </td>
  </tr>
</table>
<br>
<br>

<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="305" valign="top" class="t12"><div align="justify"><strong>ORDER ONLINE HERE</strong><br>
<br>
Please insert the number of item you wish to purchase: the product and shipping cost will be displayed automatically</div></td>
    <td width="40" class="t12">&nbsp;</td>
    <td width="305" valign="top" class="t12"><div align="justify"><strong><em>FAITES VOTRE COMMANDE EN LIGNE ICI</em></strong><br>
<br>
 <em>Veuillez ins&eacute;rer la quantit&eacute; de produits que vous d&eacute;sirez commander: le prix ainsi que les frais de livraison s'afficheront automatiquement.</em></div></td>
  </tr>
</table>
<br>
<form action="order3.php" name="form1" method="post" onSubmit="checkTotal();return document.MM_returnValue">

<input type=hidden name="subject" value="pascalbeaudenon.com - contact form">
<input type=hidden name="env_report" value="REMOTE_HOST,HTTP_USER_AGENT,REMOTE_USER,REMOTE_ADDR,HTTP_REFERER">
<input type=hidden name="redirect" value="http://www.pascalbeaudenon.com/order_bravo.html">

  <table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td colspan="2" style="font-size:11px; color:#002AA1; padding-bottom:10px"></td>
      <td width="180" valign="top" style="font-size:11px; color:#002AA1"></td>
    </tr>
    <tr> 
	<td valign="top" width="55"><img src="images/book-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>The Other Lebanon</strong><div style="font-size:10px; color:#FF0000">Available Now</div></td>
	  <td valign="top" bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>L'Autre 
        Liban</em></font></strong><div style="font-size:10px; color:#FF0000">Disponible</div></td>
      <td style="border-bottom:1px solid #D9D8D8;" align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">
	&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="book_01" type="text" id="book_01" value="0" onChange="javascript:calculate(this)" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="book_price" type="text" id="book_price" value="0" readonly="" size="2"></td>
    
  </tr>
</table>	  </td>
<td class="t12" width="180" align="right" style="border-bottom:1px solid #D9D8D8;">Book shipping fees&nbsp;<input name="book_fees" type="text" id="book_fees" value="0" readonly="" size="2"></td>
    </tr>
    <tr> 
	<td style="padding-bottom:10px;"><img src="images/cal06-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>2006 Calendar</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
        2006</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2006" type="text" id="calendar2006" onChange="javascript:calculate(this)" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar2006_price" type="text" id="calendar2006_price" value="0" readonly="" size="2"></td>
  </tr>
</table>	  </td>
<td>&nbsp;</td>
    </tr>
	 <tr> 
	 <td style="padding-bottom:10px;"><img src="images/cal07-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>2007 Calendar</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
	  <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
       2007</em></font></strong><div style="font-size:10px;">disponible</div></td>
      <td align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2007" type="text" id="calendar2007" onChange="javascript:calculate(this)" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar_price" type="text" id="calendar_price" value="0" readonly="" size="2"></td>
    
  </tr>
</table>	  </td>
<td align="right" class="t12">Calendar shipping fees&nbsp;<input name="calendar_fees" type="text" id="calendar_fees" value="0" readonly="" size="2"></td>
    </tr>
	
	
	
	<tr> 
	<td><img src="images/cal08-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>2008 Calendar</strong>
	  <div style="font-size:10px; color:#FF0000">Sold Out</div>
	  </td>
	  <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Calendrier 
       2008</em></font></strong><div style="font-size:10px; color:#FF0000">&Eacute;puis&eacute;</div></td>
      <td style="border-bottom:1px solid #D9D8D8;" align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="calendar2008" type="text" id="calendar2008" onChange="javascript:calculate(this)" value="0" size="2"></td>
    <td class="t12">&nbsp;price&nbsp;<input name="calendar2008_price" type="text" id="calendar2008_price" value="0" readonly="" size="2"></td>
    
  </tr>
</table>	  </td>
<td style="border-bottom:1px solid #D9D8D8;">&nbsp;</td>
    </tr>
	
	
	
    <tr> 
	<td><img src="images/post1-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>Postcards - set 1 </strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Cartes 
        Postales - s&eacute;rie 1</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="postcards1" type="text" id="postcards1" value="0" onChange="javascript:calculate(this)" size="2"></td>
	<td class="t12">&nbsp;price&nbsp;<input name="post1_price" type="text" id="post1_price" value="0" readonly="" size="2"></td>
    
	</tr>
	</table>	</td>
	<td align="right" class="t12">Poscards shipping fees&nbsp;<input name="post1_fees" type="text" id="post1_fees" value="0" readonly="" size="2"></td>
    </tr>
    <tr> 
	<td><img src="images/post2-thumb.jpg"></td>
      <td bgcolor="#EEEEEE" class="t12"><strong>Postcards - set 2</strong>
	  <div style="font-size:10px;">Available</div>
	  </td>
      <td bgcolor="#EEEEEE" class="t12"><strong><font color="#999999"><em>Cartes 
        Postales - s&eacute;rie 2</em></font></strong>
		<div style="font-size:10px;">Disponible</div>
	  </td>
      <td style="border-bottom:1px solid #D9D8D8;" align="right" valign="middle" class="t12">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="t12">&nbsp;Item&nbsp;<input onFocus="checkfld(this)" name="postcards2" type="text" id="postcards2" value="0" onChange="javascript:calculate(this)" size="2"></td>
	<td class="t12">&nbsp;price&nbsp;<input name="post2_price" type="text" id="post2_price" value="0" readonly="" size="2"></td>
    
	</tr>
	</table>	</td>
	<td style="border-bottom:1px solid #D9D8D8;">&nbsp;</td>
    </tr>
    
	<tr><td>&nbsp;</td>
	<td align="right" colspan="2" class="t12" style="padding-top:10px;">Products amount  <strong>$</strong> <input value="" name="prototal" type="text" size="8" readonly="readonly" style="font-weight:bold; font-size:12px; text-align:center;"></td>
	<td>&nbsp;</td></tr>
	<tr><td>&nbsp;</td>
	<td align="right" colspan="2" class="t12">Shipping fees  <strong>$</strong> <input value="" name="fees" type="text" size="8" readonly="readonly" style="font-weight:bold; font-size:12px; text-align:center;"></td>
	<td>&nbsp;</td>
	</tr>
	 
	 <tr> 
      <td align="right" class="t12"></td>
      <td align="right" valign="top" colspan="2" class="t12">Total: <strong>$</strong>
       <input name="totalnum" type="text" value="" size="8" readonly="true" style="font-weight:bold; font-size:12px; text-align:center;"> <!--&nbsp; <input name="total" type="button" onClick="javascript:calculate(this)" value="Calculate">--></td>
    <td>&nbsp;</td>
	</tr>
	<tr><td colspan="4"><div align="center">
  <br>
  <input name="total2" type="hidden" value="<?php echo $total;?>">
   <input name="continue" value="Continue" type="submit"></div></td></tr>
	
	<tr> 
      <td style="font-size:12px;padding-top:10px; padding-bottom:10px" colspan="3" class="t12">
	
	Our shipment is made via express courier (with delivery made in three to five working days)<br>
<em>Nos livraisons sont realis&eacute;es par courrier express en trois &agrave; cinq jours ouvrables.</em>
	<br><br>
Note that the shipping fee is the same for the order of 1 to 4 sets of postcards as well as from 5 to 8 and from 9 to 12.<br>
<em>Notez que le prix de livraison est le m&ecirc;me pour une commande de 1 &agrave; 4 paquets de cartes postales ainsi que de 5 &agrave; 8 et de 9 &agrave; 12</em><br><br>

	You can have the photographs 2006 and 2007 cut and framed into beautiful posters.<br>
	  <em>En coupant et en encadrant les photos des calendriers 2006 et 2007, vous les transformez en de beaux posters.</em><br><br>
	  
To order 6 or more calendars, please <a href="mailto:photo@pascalbeaudenon.com">email us</a><br>
	  <em>Pour une commande de plus de 6 calendriers, veuillez <a href="mailto:photo@pascalbeaudenon.com">nous contacter</a></em><br><br>
	  To order 7 or more Books, please <a href="mailto:photo@pascalbeaudenon.com">email us</a><br>
	  <em>Pour une commande de plus de 7 livres, veuillez <a href="mailto:photo@pascalbeaudenon.com">nous contacter</a></em><br>
<br>

</td>
    </tr>
  </table>

  
</form>


<table width="100" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="http://www.netcommerce.com.lb/logo/epayment-netcommerce.gif" width="400"
height="38" border="0" alt="E-Payment By Netcommerce"><br><br></td>
  </tr>
</table>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<table width="651" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t10">&copy; pascal beaudenon, 2005</td>
    <td width="271" align="right" class="t10">&nbsp;</td>
  </tr>
</table>
<br>
<br>
</body>
</html>