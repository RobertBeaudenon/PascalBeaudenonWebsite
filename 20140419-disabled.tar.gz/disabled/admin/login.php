<?php require_once('../Connections/conn.php'); ?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "index.php";
  $MM_redirectLoginFailed = "login.php";
  $MM_redirecttoReferrer = true;
  mysql_select_db($database_pasc, $conn);
  
  $LoginRS__query=sprintf("SELECT admin_username, admin_password FROM administrator WHERE admin_username='%s' AND admin_password='%s'",
    get_magic_quotes_gpc() ? $loginUsername : addslashes($loginUsername), get_magic_quotes_gpc() ? $password : addslashes($password)); 
   
  $LoginRS = mysql_query($LoginRS__query, $conn) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && true) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<title>Pascal Beaudenon</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<!--
var pageId = "main_r5_c5";
var src = "images/main_r5_c5_f2.gif";
-->
</script>
<style type="text/css">
<!--
.style3 {font-size: 15px ; color: #333333;}
.style15 {color: #FF0000}
-->
</style>
<script type="text/JavaScript">

<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

</head>

<body>
<div style="padding-top:20px" align="center"><a href="../"><img src="images/logo.gif" border="0"></a></div>
<table align="center" width="700" border="0" cellpadding="0" cellspacing="0" class="background_sub_below">
  <tr>
    <td align="left" valign="top" style="padding-top:10px; ">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
    
        <td valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><img src="../images/spacer.gif" width="300" height="8"></td>
            </tr>
            <tr>
              <td style="padding-bottom:12px"><div align="left">
               <span style="font-size:14px; font-weight:bold">Administrator</span><br><br>
                <p><span class="Title style3">Please Login </span><br>
                  <br>
                  </p>
              </div></td>
            </tr>
            <tr>
              <td align="right" valign="top" style="padding-right:15px;padding-top:20px"><form name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
                <table border="0" cellspacing="0" cellpadding="4">
                  <tr>
                    <td>Username:</td>
                    <td><input name="username" type="text" id="username" class="input"></td>
                  </tr>
                  <tr>
                    <td>Password: </td>
                    <td><input name="password" type="password" id="password" class="input"></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td align="right"><div align="right">
                      <input type="submit" name="Submit" value="GO" class="go">
                    </div></td>
                  </tr>
                </table>
                            </form>              </td>
            </tr>
        </table><br></td>
      </tr>
    </table></td>
  </tr>
</table>
<!--<script language="javascript">activate();</script>-->
</body>
</html>
