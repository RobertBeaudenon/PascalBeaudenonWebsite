<?php require_once('../Connections/conn.php');
mysql_select_db($database_pasc, $conn);

//mysql_select_db($database_tanmiyat, $tanmiyat);

$select = "SELECT * FROM users";
$export = mysql_query ( $select ) or die ( "Sql error : " . mysql_error( ) );
$fields = mysql_num_fields ( $export );

for ( $i = 0; $i < $fields; $i++ )
{
    $header .= mysql_field_name( $export , $i ) . "\t";
}

while( $row = mysql_fetch_row( $export ) )
{
    $line = '';
    foreach( $row as $value )
    {                                            
        if ( ( !isset( $value ) ) || ( $value == "" ) )
        {
            $value = "\t";
        }
        else
        {
            $value = str_replace( '"' , '""' , $value );
            $value = '"' . $value . '"' . "\t";
        }
        $line .= $value;
    }
    $data .= trim( $line ) . "\n";
}
$data = str_replace( "\r" , "" , $data );

if ( $data == "" )
{
    $data = "\n(0) Records Found!\n";                        
}

//print "$header\n$data";
?>
<?php
$filename = 'users.xls';
$somecontent = "$header\n$data";

// Let's make sure the file exists and is writable first.
if (is_writable($filename)) {

   // In our example we're opening $filename in append mode.
   // The file pointer is at the bottom of the file hence 
   // that's where $somecontent will go when we fwrite() it.
   if (!$handle = fopen($filename, 'w+')) {
        echo "Cannot open file ($filename)";
        exit;
   }

   // Write $somecontent to our opened file.
   if (fwrite($handle, $somecontent) === FALSE) {
       echo "Cannot write to file ($filename)";
       exit;
   }
   
   //echo "Success!";
   fclose($handle);
   echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL=' . $filename . '">';

} else {
   echo "The file $filename is not writable";
}
?>
