<?php require_once('../Connections/conn.php');
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?><?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_Recordset1 = 15;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_pasc, $conn);
$query_Recordset1 = "SELECT * FROM users ORDER BY user_id DESC";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;

$colname_details = "-1";
if (isset($_GET['id'])) {
  $colname_details = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_pasc, $conn);
$query_details = sprintf("SELECT * FROM users WHERE user_id = %s", $colname_details);
$details = mysql_query($query_details, $conn) or die(mysql_error());
$row_details = mysql_fetch_assoc($details);
$totalRows_details = mysql_num_rows($details);

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<title>Pascal Beaudenon</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<!--
var pageId = "main_r5_c5";
var src = "images/main_r5_c5_f2.gif";
-->
</script>
<script type="text/JavaScript">

<!--
function gotoURL(url)
{
	document.location.href = url;
}
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
function deleteUser(id)
{
	if(confirm ('Are you sure you want to delete this user?')){
		gotoURL("userdelete.php?id="+id);
	}
}
//-->
</script>
</head>

<body>
<div style="padding-top:20px"  align="center"><a href="../"><img src="images/logo.gif" border="0"></a></div>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="background_sub_below">
  <tr>
    <td align="left" valign="top" style="padding-top:10px; ">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
    
        <td valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><img src="../images/spacer.gif" width="300" height="8"></td>
            </tr>
            <tr>
              <td style="padding-bottom:12px">
			  
                  <div align="left"><br>
                    <a href="logout.php" style="float:right">logout</a>
                     <a style="font-size:14px; font-weight:bold" href="index.php">Administrator</a><br><br>
                    <span style="font-size:12px; font-weight:bold">Pascal Beaudenon users</span><br><br>
			  <?php if ($totalRows_details == 0) { // Show if recordset empty ?>
                    <table border="0" cellpadding="4" cellspacing="1">
                      <tr>
                        <td bgcolor="#eeeeee"><strong>Name</strong></td>
                          <td bgcolor="#eeeeee"><strong>Country</strong></td>
                          <td bgcolor="#eeeeee"><strong>Email</strong></td>
						   <td bgcolor="#eeeeee" width="100"><strong>Order</strong></td>
						    <td bgcolor="#eeeeee"><strong>Confirmation</strong></td>
						   <td bgcolor="#eeeeee"><strong>Shipment</strong></td>
                          <td><a href="export-users.php" target="_blank">Export to excel</a></td>
						  <td>&nbsp;</td>
                        </tr>
                      <?php do { ?>
                        <tr>
                          <td valign="top"><?php echo $row_Recordset1['user_name']; ?></td>
                          <td valign="top"><?php echo $row_Recordset1['user_country']; ?></td>
                          <td valign="top"><a href="mailto:<?php echo $row_Recordset1['user_email']; ?>"><?php echo $row_Recordset1['user_email']; ?></a></td>
						  <td valign="top"><?php if($row_Recordset1['user_tol']!="0") { echo "Book(s)"; } else { echo "Others"; }?></td>
						  <td valign="top"><?php echo $row_Recordset1['confirmation'];?></td>
						  <td>
						  <?php if($row_Recordset1['shipment']=="1") {?>
						  <a href="shipment.php?id=<?php echo $row_Recordset1['user_id'];?>" class="checked">shipment: delivered</a>
						  <?php } else {?>
						  <a href="shipment.php?id=<?php echo $row_Recordset1['user_id'];?>" class="unchecked">Shipment: not delivered</a>
						  <?php }?>						  </td>
                          <td valign="top"><a href="users.php?id=<?php echo $row_Recordset1['user_id']; ?>"><img src="images/icon_details.gif" width="10" height="11" border="0"> details</a></td>
						  <td width="50" valign="top"><a href="#" onclick="deleteUser(<?php echo $row_Recordset1['user_id']; ?>)"><img src="images/icon_delete.gif" border="0" />&nbsp;delete</a></td>
                        </tr>
                        <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
                    </table>
                    <div align="left"><br>
                      Showing <?php echo ($startRow_Recordset1 + 1) ?> to <?php echo min($startRow_Recordset1 + $maxRows_Recordset1, $totalRows_Recordset1) ?> of <?php echo $totalRows_Recordset1 ?> </div>
                    <table width="40%" border="0">
                        <tr>
                          <td width="23%" align="center"><?php if ($pageNum_Recordset1 > 0) { // Show if not first page ?>
                              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, 0, $queryString_Recordset1); ?>"><img src="images/icon_first.gif" width="10" height="10" border=0> First</a>
                              <?php } // Show if not first page ?>                                                    </td>
                          <td width="31%" align="center"><?php if ($pageNum_Recordset1 > 0) { // Show if not first page ?>
                              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, max(0, $pageNum_Recordset1 - 1), $queryString_Recordset1); ?>"><img src="images/icon_prev.gif" width="9" height="8" border=0> Previous</a>
                              <?php } // Show if not first page ?>                                                    </td>
                          <td width="23%" align="center"><?php if ($pageNum_Recordset1 < $totalPages_Recordset1) { // Show if not last page ?>
                              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, min($totalPages_Recordset1, $pageNum_Recordset1 + 1), $queryString_Recordset1); ?>">Next <img src="images/icon_next.gif" width="9" height="8" border=0></a>
                              <?php } // Show if not last page ?>                                                    </td>
                          <td width="23%" align="center"><?php if ($pageNum_Recordset1 < $totalPages_Recordset1) { // Show if not last page ?>
                              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, $totalPages_Recordset1, $queryString_Recordset1); ?>">Last <img src="images/icon_last.gif" width="10" height="10" border=0></a>
                              <?php } // Show if not last page ?>                                                    </td>
                        </tr>
                      </table>
                  
                  <?php } // Show if recordset empty ?>
                  </div>
<?php if ($totalRows_details > 0) { // Show if recordset not empty ?>
<h3><br>
  User Details - <a href="users.php" class="more">Back to list </a></h3>
 <table cellpadding="3" cellspacing="1"> 
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>confirmation:</strong>&nbsp;</td>
    <td align="left" bgcolor="#D7E3F1"><strong><?php echo $row_details['confirmation']; ?></strong></td>
    </tr>
	</table><br>
  
<table border="0" cellspacing="1" cellpadding="3">
<tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Order Date:</strong>&nbsp;</td>
    <td align="left" bgcolor="#D7E3F1"><strong><?php echo $row_details['datenow']; ?></strong></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Order Number:</strong>&nbsp;</td>
    <td align="left" bgcolor="#D7E3F1"><strong><?php echo $row_details['order_id']; ?></strong></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Name:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_name']; ?></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Email:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_email']; ?></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Phone: </strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_phone']; ?>    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Address: </strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_adress']; ?></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>City:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_city']; ?></td>
    </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>State:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_state']; ?></td>
    </tr>
	<tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Postal Code:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_postalcode']; ?></td>
    </tr>
	<tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Country:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_country']; ?></td>
    </tr>
	<tr>
    <td align="left" bgcolor="#D7E3F1"><strong>CPF number:</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['user_cpf']; ?></td>
    </tr>
	<tr>
    <td align="left" bgcolor="#D7E3F1"><strong>How did you hear about<br>The Other Lebanon?</strong></td>
    <td align="left" bgcolor="#D7E3F1"><?php echo $row_details['message']; ?></td>
    </tr>
</table>
<strong><br>
Shopping info:</strong>
<table border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td width="160" align="left" bgcolor="#D7E3F1"><strong>The Other Lebanon: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_tol']; ?></td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>2006 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_calendar2006']; ?></td>
  </tr>
   <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>2007 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_calendar2007']; ?></td>
  </tr>
    <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>2008 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_calendar2008']; ?></td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>2009 Calendar:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_calendar2009']; ?></td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Postcards - Set 1: </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_postcard1']; ?></td>
  </tr>
  <tr>
    <td align="left" bgcolor="#D7E3F1"><strong>Postcards - Set 2:</strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_postcard2']; ?></td>
  </tr>
</table>
<br>
<table border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td width="142" align="left" bgcolor="#D7E3F1" style="padding-left:4px;"><strong>BILL </strong></td>
    <td bgcolor="#D7E3F1"><?php echo $row_details['user_bill']; ?></td>
  </tr>
</table>
<br>
<table border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td width="142" align="left" bgcolor="#D7E3F1" style="padding-left:4px;"><strong>Shipment</strong></td>
    <td bgcolor="#D7E3F1"><?php if($row_details['shipment']==0) { echo "not delivered";} else { echo "delivered"; }?></td>
  </tr>
</table>


<br>
<?php } // Show if recordset not empty ?></td>
            </tr>
            <tr>
              <td align="right" valign="top" style="padding-right:15px;padding-top:20px">&nbsp;</td>
            </tr>
        </table>
		<br></td>
      </tr>
    </table></td>
  </tr>
</table>
<!--<script language="javascript">activate();</script>-->
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($details);
?>
