<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<title>Pascal Beaudenon</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<!--
var pageId = "main_r5_c5";
var src = "images/main_r5_c5_f2.gif";
-->
</script>
<style type="text/css">
<!--
.style3 {font-size: 15px ; color: #333333;}
.style15 {color: #FF0000}
-->
</style>
<script type="text/JavaScript">

<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

</head>

<body>
<div style="padding-top:20px" align="center"><a href="../"><img src="images/logo.gif" border="0"></a></div>
<table align="center" width="700" border="0" cellpadding="0" cellspacing="0" class="background_sub_below">
  <tr>
    <td align="left" valign="top" style="padding-top:10px; ">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
    
        <td valign="top"  >
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><img src="../images/spacer.gif" width="300" height="8"></td>
            </tr>
            <tr>
              <td style="padding-bottom:12px"><div align="left">
                <a href="logout.php" style="float:right">logout</a>
                <br>
                  <span style="font-size:14px; font-weight:bold">Administrator</span><br><br>
              
                - <a style="font-size:11px; font-weight:bold" href="users.php">Manage users</a> 
                
              </div></td>
            </tr>
            <tr>
              <td align="right" valign="top" style="padding-right:15px;padding-top:20px">&nbsp;</td>
            </tr>
        </table><br></td>
      </tr>
    </table></td>
  </tr>
</table>
<!--<script language="javascript">activate();</script>-->
</body>
</html>
