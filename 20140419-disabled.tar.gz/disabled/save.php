<?php require_once('Connections/conn.php');
mysql_select_db($database_pasc, $conn);

require("includes/class.phpmailer.php");
require("includes/sendmail4.php");
require("includes/msg4.php");


if($_POST["Submit"]=="Continue")
  { 
$user_name=$_POST["name"];                                                           
$adress=$_POST["address"];
$city=$_POST["city"];
$state=$_POST["state"];                                                           
$zip=$_POST["Postal_code"];
$country=$_POST["country"];
$cpf1=$_POST["cpf"];
$cpf2=$_POST["cpf2"];
$cpf = $cpf1 . "-" . $cpf2;
$email=$_POST["email"];
$phone=$_POST["phone"];
$message=$_POST["message"];

$tol = $_POST["tol"];
$calendar2006 = $_POST["calendar2006"];
$calendar2007 = $_POST["calendar2007"];
$calendar2008 = $_POST["calendar2008"];
$calendar2009 = $_POST["calendar2009"];
$postcards1 = $_POST["postcards1"];
$postcards2 = $_POST["postcards2"];
$datenow = $_POST["datenow"];

$select = "SELECT order_id FROM users ORDER BY user_id DESC LIMIT 0,1";
$rec = mysql_query($select);
$n = mysql_num_rows($rec);
$res = mysql_fetch_array($rec);

if($n=="0") {
$txtIndex = "10000";
}
else { $txtIndex = $res["order_id"] + 1;
}

$textAmount=$_POST["txtAmount"];
$txtCurrency=$_POST["txtCurrency"];
$txtMerchNum=$_POST["txtMerchNum"];
$txthttp=$_POST["txthttp"];

/*
echo $textAmount . "<br>";
echo $txtCurrency . "<br>";
echo $txtIndex . "<br>";
echo $txtMerchNum . "<br>";
echo $txthttp;
*/
$book_01_eng=$_POST["book_01_eng"];
$book_01_fr=$_POST["book_01_fr"];
$calendar2009_fr=$_POST["calendar2009_fr"];
$calendar2009_eng=$_POST["calendar2009_eng"];
$calendar2006_eng=$_POST["calendar2006_eng"];
$calendar2006_fr=$_POST["calendar2006_fr"];
$post1_eng=$_POST["post1_eng"];
$post1_fr=$_POST["post1_fr"];
$post2_eng=$_POST["post2_eng"];
$post2_fr=$_POST["post2_fr"];

$sqlinsert="insert into users (user_name,user_adress, user_city,user_state,user_postalcode,user_country,user_cpf,user_email,user_phone,user_tol,user_calendar2006,user_calendar2007,user_calendar2008,user_calendar2009,user_postcard1,user_postcard2,user_bill, order_id, datenow, message, book_01_eng, book_01_fr, calendar2009_fr, calendar2009_eng, calendar2006_eng, calendar2006_fr, post1_eng, post1_fr, post2_eng, post2_fr) 
values('$user_name','$adress','$city','$state', '$zip','$country','$cpf','$email','$phone','$tol','$calendar2006','$calendar2007','$calendar2008','$calendar2009','$postcards1','$postcards2','$textAmount', '$txtIndex', '$datenow', '$message', '$book_01_eng', '$book_01_fr', '$calendar2009_fr', '$calendar2009_eng', '$calendar2006_eng', '$calendar2006_fr', '$post1_eng', '$post1_fr', '$post2_eng', '$post2_fr')"; 

if(!mysql_query($sqlinsert)) {
 echo mysql_error();
 die();
 exit;
}

sendemail4_pascal($user_name, $user_email, $tol, $calendar2006, $calendar2007, $calendar2008, $calendar2009, $postcards1, $postcards2, $textAmount,$book_01_eng,$book_01_fr,$calendar2009_fr,$calendar2009_eng,$calendar2006_eng,$calendar2006_fr,$post1_eng,$post1_fr,$post2_eng,$post2_fr);


echo '<html><head></head><body><form name="pay" action="https://www.netcommercepay.com/iPAY/Default.asp" method="post">
<input name="txtAmount" type="hidden" value="' . $textAmount .'">
<input name="txtCurrency" type="hidden" value="' . $txtCurrency . '">
<input name="txtIndex" type="hidden" value="' . $txtIndex . '">
<input name="txtMerchNum" type="hidden" value="' . $txtMerchNum . '">
<input name="txthttp" type="hidden" value="' . $txthttp . '">
<script language="javascript">document.pay.submit();</script>
</form></body></html>';

exit;

}
?>
