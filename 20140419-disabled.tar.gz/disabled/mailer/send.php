
<?php
require("class.phpmailer.php");

if ($_POST["using"] == "phpmailer"){
	$mail = new PHPMailer();
	$mail->IsHTML(true); 
	$mail->From = $_POST["mailfrom"];
	$mail->FromName = "Mail Tester";
	$mail->Subject = "TEST EMAIL";
	$mail->Body = $_POST["body"];
	$mail->AddAddress($_POST["mailto"]);
	
	// echo errors in case there are any
	if(!$mail->Send())
	{
	   echo "Error sending mail:" . $mail->ErrorInfo;
	}
	else
	{
	 echo "Mail sent! Please check your inbox. <BR>If you didnt get a new email this means the server is not sending. ";
	}
} else {
	if(!@mail($_POST["mailto"], "TEST EMAIL", $_POST["body"]))
	{
	   echo "Error sending mail using mail() function";
	}
	else
	{
	 echo "Mail sent! Please check your inbox. <BR>If you didnt get a new email this means the server is not sending. ";
	}
}
?>