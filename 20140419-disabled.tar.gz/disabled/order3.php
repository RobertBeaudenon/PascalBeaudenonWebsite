<?php require_once('Connections/conn.php');


if($_POST["continue"]=="Continue")
{ 
$book_01_eng=$_POST["book_01_eng"];
$book_01_fr=$_POST["book_01_fr"];
$calendar2009_fr=$_POST["calendar2009_fr"];
$calendar2009_eng=$_POST["calendar2009_eng"];
$calendar2006_eng=$_POST["calendar2006_eng"];
$calendar2006_fr=$_POST["calendar2006_fr"];
$post1_eng=$_POST["post1_eng"];
$post1_fr=$_POST["post1_fr"];
$post2_eng=$_POST["post2_eng"];
$post2_fr=$_POST["post2_fr"];

		$tol=$_POST["book_01"];
		$calendar2006=$_POST["calendar2006"];
		$calendar2007=$_POST["calendar2007"];
		$calendar2008=$_POST["calendar2008"];
		$calendar2009=$_POST["calendar2009"];
		$postcards1=$_POST["postcards1"];
		$postcards2=$_POST["postcards2"];
		$total= $_POST["totalnum"];
		
		if($total=="" or $total=="0") {
			header("location:order2.php");
		}
	
}




//echo $total;
//exit;
?>
<html>
<head>
<title>Pascal Beaudenon - Landscape Photographies of Lebanon</title>
<meta name="description" content="Official website of landscape photographer Pascal Beaudenon. Panoramic photographies from all over Lebanon.">
<meta name="keywords" content="beaudenon,pascalbeaudenon,pascal beaudenon,landscape photography,landscape photographer,photo,photos,photographies,photographe,lebanon,photos lebanon,lebanon photos,liban,photos liban,liban photos,photographie panoramique,photo panoramique,photos panoramiques">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" CONTENT="en,fr">
<meta name="robots" content="index,follow">
<meta name="author" content="Powered by ZWYX.org">
<meta name="copyright" content="copyright (c) www.pascalbeaudenon.com">
<link href="css/main.css" rel="stylesheet" type="text/css">


<script language="JavaScript" src="js/main.js"></script>
<script language="JavaScript" src="js/formail_check.js"></script>

<script type="text/JavaScript">

function setStyleById(i, p, v) {
	var n = document.getElementById(i);
	n.style[p] = v;
}

function checkCountry()
{
	if(document.form1.country.value == "BRA")
	{
		setStyleById('div_cpf', 'display', 'block');		
	} else {
		setStyleById('div_cpf', 'display', 'none');
	}
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  }
  
  
if(!document.form1.country.value.length){
				errors += '- Country is required \n'
}
if(!document.form1.state.value.length){
				errors += '- State is required \n'
}
  
	if(document.getElementById('div_cpf').style.display == "block"){
			if((document.form1.cpf.value.length != 9) || (document.form1.cpf2.value.length != 2) || (isNaN(parseInt(document.form1.cpf2.value))) || (isNaN(parseInt(document.form1.cpf.value)))){
				errors += '- Fill in the CPF Number correctly \n'
			}
			
		}
   
  document.MM_returnValue = (errors == '');



	if (errors.length) {
		alert('The following error(s) occurred:\n'+errors)
	 }
}	

//-->
</script>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="t12" align="right"><a href="contact.html" class="link_menu"><b>CONTACT</b></a></td>
</tr>
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="bottom"> 
    <td width="470" class="t12"><a href="photos_album2.html" class="link_menu"><strong>PHOTOGRAPHIES</strong></a> 
      <strong>&nbsp;-&nbsp; <a href="publications_lebanon1_map.html" class="link_menu">THE BOOK</a> &nbsp;-&nbsp; <a href="publications.html" class="link_menu"><font color="#FF0000">PUBLICATIONS</font></a> &nbsp;-&nbsp; <a href="exhibitons.html" class="link_menu">EXHIBITIONS</a> &nbsp;-&nbsp; <a href="info.html" class="link_menu">INFO</a> &nbsp;-&nbsp; <a href="order2.php" class="link_menu">ORDER</a></strong></td>
    <td width="180" align="right"><a href=""><img src="pics/logo_pascal_beaudenon_0.gif" alt="Pascal Beaudenon - landscape photographies - photographies panoramiques" width="160" height="20" border="0"></a></td>
  </tr>
</table>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t13">P u b l i c a t i o n s</td>
    <td width="270">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><strong>The Other Lebanon | <em>L'Autre Liban</em></strong> - <span class="t10">publication: 
      dec. 2005 </span><br>
      <br>
      <table border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="t12"><strong><a href="publications_lebanon1_forword.html">Forword</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="photos_album2.html">Photos</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_lebanon1_map.html">The 
            Book</a></strong></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="publications_calendar2009.html"><strong class="Blue">Calendar 
            2009</strong></a></td>
		   <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><a href="other-calendars.html"><strong>Other Products</strong></a></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><strong><a href="publications_postcards.html">Postcards</a></strong></td>
        </tr>
        <tr> 
          <td class="t12"><img src="pics/pixel.gif" width="1" height="4"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
          <td class="t12"><img src="pics/pixel.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td class="t12"><em><a href="publications_lebanon1_forword.html">Pr&eacute;face</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="photos_album2.html">Photos</a></em></td>
          <td class="t12"><em>&nbsp;&nbsp;|&nbsp;&nbsp;</em></td>
          <td class="t12"><em><a href="publications_lebanon1_map.html">Le Livre</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="publications_calendar2009.html"><span class="Blue">Calendrier 
            2009</span></a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td nowrap class="t12"><em><a href="other-calendars.html">Autres Produits</a></em></td>
          <td class="t12"><strong>&nbsp;&nbsp;|&nbsp;&nbsp;</strong></td>
          <td class="t12"><em><a href="publications_postcards.html">Cartes Postales</a></em></td>
        </tr>
      </table> </td>
  </tr>
</table>
<br>
<br>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="305" valign="top" class="t12"><div align="justify">To proceed with your order, please fill in the form below:</div></td>
    <td width="40" class="t12">&nbsp;</td>
    <td width="305" valign="top" class="t12"><div align="justify"> <em>Pour confirmer votre commande, veuillez remplir le formulaire ci-dessous:</em></div></td>
  </tr>
</table>
<br>

<form action="save.php" method="post" name="form1" onSubmit="MM_validateForm('name','','R','city','','R','Postal_code','','R','email','','RisEmail','phone','','R','address','','R','message','','R');return document.MM_returnValue">

<input type=hidden name="subject" value="pascalbeaudenon.com - contact form">
<input type=hidden name="env_report" value="REMOTE_HOST,HTTP_USER_AGENT,REMOTE_USER,REMOTE_ADDR,HTTP_REFERER">
<input type=hidden name="redirect" value="http://www.pascalbeaudenon.com/order_bravo.html">
<table width="650" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr> 
      <td width="22%" class="t12"><font face="Arial, Helvetica, sans-serif">Name *</font></td>
    <td width="25%" class="t12"><font color="#999999"><em>Nom *</em></font></td>
    <td width="53%"> <input name="name" type="text" value="" id="name" size="35" maxlength="50"> 
    </td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">Shipping address: *</font></td>
    <td class="t12"><font color="#999999"><em>Adresse de livraison *</em></font></td>
    <td><textarea name="address" cols="20" rows="3"></textarea></td>
  </tr>
  <tr>
  	<td valign="top"><span class="s1"><font size="-2" face="Arial, Helvetica, sans-serif">PO Boxes are not accepted by courier express delivery: please insert full address</font></span></td>
	<td valign="top"><span class="s1"><font size="-2" face="Arial, Helvetica, sans-serif">les boites postales ne sont pas acceptees par les compagnies de courrier express: veuillez inserer une adresse complete</font></span></td>
	<td></td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">City *</font></td>
    <td class="t12"><font color="#999999"><em>Ville</em></font></td>
    <td><input name="city" type="text" id="city" size="20" maxlength="40"></td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">State or Province *</font></td>
    <td class="t12"><font color="#999999"><em>Etat ou Province *</em></font></td>
    <td><select name="state" id="state">
        <option value="" selected="selected">Choose State</option>
        <option value="XX" >Outside US and Canada</option>
        <option value="AL" >Alabama</option>
        <option value="AK" >Alaska</option>
        <option value="AZ" >Arizona</option>
        <option value="AR" >Arkansas</option>
        <option value="CA" >California</option>
        <option value="CO" >Colorado</option>
        <option value="CT" >Connecticut</option>
        <option value="DE" >Delaware</option>
        <option value="DC" >District Of Columbia</option>
        <option value="FL" >Florida</option>
        <option value="GA" >Georgia</option>
        <option value="HI" >Hawaii</option>
        <option value="ID" >Idaho</option>
        <option value="IL" >Illinois</option>
        <option value="IN" >Indiana</option>
        <option value="IA" >Iowa</option>
        <option value="KS" >Kansas</option>
        <option value="KY" >Kentucky</option>
        <option value="LA" >Louisiana</option>
        <option value="ME" >Maine</option>
        <option value="MD" >Maryland</option>
        <option value="MA" >Massachusetts</option>
        <option value="MI" >Michigan</option>
        <option value="MN" >Minnesota</option>
        <option value="MS" >Mississippi</option>
        <option value="MO" >Missouri</option>
        <option value="MT" >Montana</option>
        <option value="NE" >Nebraska</option>
        <option value="NV" >Nevada</option>
        <option value="NH" >New Hampshire</option>
        <option value="NJ" >New Jersey</option>
        <option value="NM" >New Mexico</option>
        <option value="NY" >New York</option>
        <option value="NC" >North Carolina</option>
        <option value="ND" >North Dakota</option>
        <option value="OH" >Ohio</option>
        <option value="OK" >Oklahoma</option>
        <option value="OR" >Oregon</option>
        <option value="PA" >Pennsylvania</option>
        <option value="PR" >Puerto Rico</option>
        <option value="RI" >Rhode Island</option>
        <option value="SC" >South Carolina</option>
        <option value="SD" >South Dakota</option>
        <option value="TN" >Tennessee</option>
        <option value="TX" >Texas</option>
        <option value="UT" >Utah</option>
        <option value="VT" >Vermont</option>
        <option value="VA" >Virginia</option>
        <option value="WA" >Washington</option>
        <option value="WV" >West Virginia</option>
        <option value="WI" >Wisconsin</option>
        <option value="WY" >Wyoming</option>
        <option value="DC" >Washington DC</option>
        <option value="AS" >American Samoa</option>
        <option value="GU" >Guam</option>
        <option value="MP" >Northern Mariana Is</option>
        <option value="PW" >Palau</option>
        <option value="VI" >Virgin Islands</option>
        <option value="AA" >Armed Forces Americas</option>
        <option value="AE" >Armed Forces Europe</option>
        <option value="AP" >Armed Forces Pacific</option>
        <option value="AB" >Alberta</option>
        <option value="BC" >British Columbia</option>
        <option value="MB" >Manitoba</option>
        <option value="NB" >New Brunswick</option>
        <option value="NF" >Newfoundland</option>
        <option value="NT" >Northwest Territories</option>
        <option value="NS" >Nova Scotia</option>
        <option value="NU" >Nunavut</option>
        <option value="ON" >Ontario</option>
        <option value="PE" >Prince Edward Island</option>
        <option value="QC" >Quebec</option>
        <option value="SK" >Saskatchewan</option>
        <option value="YT" >Yukon Territory</option>
      </select>
	  </td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">Postal Code *</font></td>
    <td class="t12"><font color="#999999"><em>Code Postal *</em></font></td>
    <td><input name="Postal_code" type="text" id="Postal_code" size="20" maxlength="20"></td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">Country *</font></td>
    <td class="t12"><font color="#999999"><em>Pays *</em></font></td>
    <td><select name="country" id="country" onChange="checkCountry()">
        <option value="" selected>Choose Country</option>
        <option value="AFG" > Afghanistan</option>
        <option value="ALB" > Albania</option>
        <option value="DZA" > Algeria</option>
        <option value="ASM" > American Samoa</option>
        <option value="AND" > Andorra</option>
        <option value="AGO" > Angola</option>
        <option value="AIA" > Anguilla</option>
        <option value="ATA" > Antarctica</option>
        <option value="ATG" > Antigua and Barbuda</option>
        <option value="ARG" > Argentina</option>
        <option value="ARM" > Armenia</option>
        <option value="ABW" > Aruba</option>
        <option value="AUS" > Australia</option>
        <option value="AUT" > Austria</option>
        <option value="AZE" > Azerbaijan</option>
        <option value="BHS" > Bahamas</option>
        <option value="BHR" > Bahrain</option>
        <option value="BGD" > Bangladesh</option>
        <option value="BRB" > Barbados</option>
        <option value="BLR" > Belarus</option>
        <option value="BEL" > Belgium</option>
        <option value="BLZ" > Belize</option>
        <option value="BEN" > Benin</option>
        <option value="BMU" > Bermuda</option>
        <option value="BTN" > Bhutan</option>
        <option value="BOL" > Bolivia</option>
        <option value="BIH" > Bosnia and Herzegovina</option>
        <option value="BWA" > Botswana</option>
        <option value="BVT" > Bouvet Island</option>
        <option value="BRA" > Brazil</option>
        <option value="IOT" > British Indian Ocean Territory</option>
        <option value="BRN" > Brunei Darussalam</option>
        <option value="BGR" > Bulgaria</option>
        <option value="BFA" > Burkina Faso</option>
        <option value="BDI" > Burundi</option>
        <option value="KHM" > Cambodia</option>
        <option value="CMR" > Cameroon</option>
        <option value="CAN" > Canada</option>
        <option value="CPV" > Cape Verde</option>
        <option value="CYM" > Cayman Islands</option>
        <option value="CAF" > Central African Republic</option>
        <option value="TCD" > Chad</option>
        <option value="CHL" > Chile</option>
        <option value="CHN" > China</option>
        <option value="CXR" > Christmas Island</option>
        <option value="CCK" > Cocos (Keeling) Islands</option>
        <option value="COL" > Colombia</option>
        <option value="COM" > Comoros</option>
        <option value="COG" > Congo</option>
        <option value="COD" > Congo, the Democratic Republic of the</option>
        <option value="COK" > Cook Islands</option>
        <option value="CRI" > Costa Rica</option>
        <option value="CIV" > Cote D'ivoire</option>
        <option value="HRV" > Croatia (Hrvatska)</option>
        <option value="CUB" > Cuba</option>
        <option value="CYP" > Cyprus</option>
        <option value="CZE" > Czech Republic</option>
        <option value="DNK" > Denmark</option>
        <option value="DJI" > Djibouti</option>
        <option value="DMA" > Dominica</option>
        <option value="DOM" > Dominican Republic</option>
        <option value="ECU" > Ecuador</option>
        <option value="EGY" > Egypt</option>
        <option value="SLV" > El Salvador</option>
        <option value="GNQ" > Equatorial Guinea</option>
        <option value="ERI" > Eritrea</option>
        <option value="EST" > Estonia</option>
        <option value="ETH" > Ethiopia</option>
        <option value="FLK" > Falkland Islands (Malvinas)</option>
        <option value="FRO" > Faroe Islands</option>
        <option value="FJI" > Fiji</option>
        <option value="FIN" > Finland</option>
        <option value="FRA" > France</option>
        <option value="FXX" > France, Metropolitan</option>
        <option value="GUF" > French Guiana</option>
        <option value="PYF" > French Polynesia</option>
        <option value="ATF" > French Southern Territories</option>
        <option value="GAB" > Gabon</option>
        <option value="GMB" > Gambia</option>
        <option value="GEO" > Georgia</option>
        <option value="DEU" > Germany</option>
        <option value="GHA" > Ghana</option>
        <option value="GIB" > Gibraltar</option>
        <option value="GRC" > Greece</option>
        <option value="GRL" > Greenland</option>
        <option value="GRD" > Grenada</option>
        <option value="GLP" > Guadeloupe</option>
        <option value="GUM" > Guam</option>
        <option value="GTM" > Guatemala</option>
        <option value="GIN" > Guinea</option>
        <option value="GNB" > Guinea-Bissau</option>
        <option value="GUY" > Guyana</option>
        <option value="HTI" > Haiti</option>
        <option value="HMD" > Heard Island and Mcdonald Islands</option>
        <option value="HND" > Honduras</option>
        <option value="HKG" > Hong Kong</option>
        <option value="HUN" > Hungary</option>
        <option value="ISL" > Iceland</option>
        <option value="IND" > India</option>
        <option value="IDN" > Indonesia</option>
        <option value="IRN" > Iran, Islamic Republic of</option>
        <option value="IRQ" > Iraq</option>
        <option value="IRL" > Ireland</option>
        <option value="ISR" > Israel</option>
        <option value="ITA" > Italy</option>
        <option value="JAM" > Jamaica</option>
        <option value="JPN" > Japan</option>
        <option value="JOR" > Jordan</option>
        <option value="KAZ" > Kazakhstan</option>
        <option value="KEN" > Kenya</option>
        <option value="KIR" > Kiribati</option>
        <option value="PRK" > Korea, Democratic People's Republic of</option>
        <option value="KOR" > Korea, Republic of</option>
        <option value="KWT" > Kuwait</option>
        <option value="KGZ" > Kyrgyzstan</option>
        <option value="LAO" > Lao People's Democratic Republic</option>
        <option value="LVA" > Latvia</option>
        <option value="LBN" > Lebanon</option>
        <option value="LSO" > Lesotho</option>
        <option value="LBR" > Liberia</option>
        <option value="LBY" > Libyan Arab Jamahiriya</option>
        <option value="LIE" > Liechtenstein</option>
        <option value="LTU" > Lithuania</option>
        <option value="LUX" > Luxembourg</option>
        <option value="MAC" > Macao</option>
        <option value="MKD" > Macedonia, the Former Yugoslav Republic of</option>
        <option value="MDG" > Madagascar</option>
        <option value="MWI" > Malawi</option>
        <option value="MYS" > Malaysia</option>
        <option value="MDV" > Maldives</option>
        <option value="MLI" > Mali</option>
        <option value="MLT" > Malta</option>
        <option value="MHL" > Marshall Islands</option>
        <option value="MTQ" > Martinique</option>
        <option value="MRT" > Mauritania</option>
        <option value="MUS" > Mauritius</option>
        <option value="MYT" > Mayotte</option>
        <option value="MEX" > Mexico</option>
        <option value="FSM" > Micronesia, Federated States of</option>
        <option value="MDA" > Moldova, Republic of</option>
        <option value="MCO" > Monaco</option>
        <option value="MNG" > Mongolia</option>
        <option value="MSR" > Montserrat</option>
        <option value="MAR" > Morocco</option>
        <option value="MOZ" > Mozambique</option>
        <option value="MMR" > Myanmar</option>
        <option value="NAM" > Namibia</option>
        <option value="NRU" > Nauru</option>
        <option value="NPL" > Nepal</option>
        <option value="NLD" > Netherlands</option>
        <option value="ANT" > Netherlands Antilles</option>
        <option value="NCL" > New Caledonia</option>
        <option value="NZL" > New Zealand</option>
        <option value="NIC" > Nicaragua</option>
        <option value="NER" > Niger</option>
        <option value="NGA" > Nigeria</option>
        <option value="NIU" > Niue</option>
        <option value="NFK" > Norfolk Island</option>
        <option value="MNP" > Northern Mariana Islands</option>
        <option value="NOR" > Norway</option>
        <option value="OMN" > Oman</option>
        <option value="PAK" > Pakistan</option>
        <option value="PLW" > Palau</option>
        <option value="PSE" > Palestinian Territory, Occupied</option>
        <option value="PAN" > Panama</option>
        <option value="PNG" > Papua New Guinea</option>
        <option value="PRY" > Paraguay</option>
        <option value="PER" > Peru</option>
        <option value="PHL" > Philippines</option>
        <option value="PCN" > Pitcairn</option>
        <option value="POL" > Poland</option>
        <option value="PRT" > Portugal</option>
        <option value="PRI" > Puerto Rico</option>
        <option value="QAT" > Qatar</option>
        <option value="REU" > Reunion</option>
        <option value="ROU" > Romania</option>
        <option value="RUS" > Russian Federation</option>
        <option value="RWA" > Rwanda</option>
        <option value="SHN" > Saint Helena</option>
        <option value="KNA" > Saint Kitts and Nevis</option>
        <option value="LCA" > Saint Lucia</option>
        <option value="SPM" > Saint Pierre and Miquelon</option>
        <option value="VCT" > Saint Vincent and the Grenadines</option>
        <option value="WSM" > Samoa</option>
        <option value="SMR" > San Marino</option>
        <option value="STP" > Sao Tome and Principe</option>
        <option value="SAU" > Saudi Arabia</option>
        <option value="SEN" > Senegal</option>
        <option value="SCG" > Serbia and Montenegro</option>
        <option value="SYC" > Seychelles</option>
        <option value="SLE" > Sierra Leone</option>
        <option value="SGP" > Singapore</option>
        <option value="SVK" > Slovakia</option>
        <option value="SVN" > Slovenia</option>
        <option value="SLB" > Solomon Islands</option>
        <option value="SOM" > Somalia</option>
        <option value="ZAF" > South Africa</option>
        <option value="SGS" > South Georgia and the South Sandwich Islands</option>
        <option value="ESP" > Spain</option>
        <option value="LKA" > Sri Lanka</option>
        <option value="SDN" > Sudan</option>
        <option value="SUR" > Suriname</option>
        <option value="SJM" > Svalbard and Jan Mayen Islands</option>
        <option value="SWZ" > Swaziland</option>
        <option value="SWE" > Sweden</option>
        <option value="CHE" > Switzerland</option>
        <option value="SYR" > Syrian Arab Republic</option>
        <option value="TWN" > Taiwan</option>
        <option value="TJK" > Tajikistan</option>
        <option value="TZA" > Tanzania, United Republic of</option>
        <option value="THA" > Thailand</option>
        <option value="TLS" > Timor-Leste</option>
        <option value="TGO" > Togo</option>
        <option value="TKL" > Tokelau</option>
        <option value="TON" > Tonga</option>
        <option value="TTO" > Trinidad and Tobago</option>
        <option value="TUN" > Tunisia</option>
        <option value="TUR" > Turkey</option>
        <option value="TKM" > Turkmenistan</option>
        <option value="TCA" > Turks and Caicos Islands</option>
        <option value="TUV" > Tuvalu</option>
        <option value="UGA" > Uganda</option>
        <option value="UKR" > Ukraine</option>
        <option value="ARE" > United Arab Emirates</option>
        <option value="GBR" > United Kingdom</option>
        <option value="USA" > United States</option>
        <option value="UMI" > United States Minor Outlying Islands</option>
        <option value="URY" > Uruguay</option>
        <option value="UZB" > Uzbekistan</option>
        <option value="VUT" > Vanuatu</option>
        <option value="VAT" > Vatican City State (Holy See)</option>
        <option value="VEN" > Venezuela</option>
        <option value="VNM" > Viet Nam</option>
        <option value="VGB" > Virgin Islands, British</option>
        <option value="VIR" > Virgin Islands, U.S.</option>
        <option value="WLF" > Wallis and Futuna Islands</option>
        <option value="ESH" > Western Sahara</option>
        <option value="YEM" > Yemen</option>
        <option value="YUG" > Yugoslavia</option>
        <option value="ZAR" > Zaire</option>
        <option value="ZMB" > Zambia</option>
        <option value="ZWE" > Zimbabwe</option>
      </select>
	  <div id="div_cpf" style="padding-bottom:10px; padding-top:5px; display:none" class="t12">CPF Number:&nbsp;* <input name="cpf" type="text" id="cpf" size="15" maxlength="20"> - <input value="" name="cpf2" size="6" type="text" id="cpf2"></div>
	  </td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">Email *</font></td>
    <td class="t12"><font color="#999999"><em>Email *</em></font></td>
    <td><input name="email" type="text" id="email" size="35" maxlength="64"> <br> 
      <span class="s1"><font size="-2" face="Arial, Helvetica, sans-serif">if 
      possible, avoid free account such as yahoo &amp; hotmail</font></span></td>
  </tr>
  <tr> 
    <td class="t12"><font face="Arial, Helvetica, sans-serif">Phone *</font></td>
    <td class="t12"><font color="#999999"><em>Tel *</em></font></td>
    <td><input name="phone" type="text" id="phone" value="" size="35" maxlength="35"> <br> 
      <span class="s1"><small><b><font size="-2" face="Arial, Helvetica, sans-serif">Format:</font></b><font size="-2" face="Arial, Helvetica, sans-serif"> 
      US: xxx-xxx-xxxx &nbsp;| &nbsp;International: 8 character min</font></small> 
      </span></td>
  </tr>
  <tr> 
    <td valign="top" class="t12"><font face="Arial, Helvetica, sans-serif">How did you hear about The Other Lebanon? *</font></td>
    <td valign="top" class="t12"><font color="#999999"><em>Comment avez-vous d&eacute;couvert L'Autre Liban? *</em></font></td>
    <td><textarea name="message" cols="20" rows="3"></textarea></td>
  </tr>
  
  <tr><td colspan="3" style="font-size:11px; padding-bottom:5px; padding-top:5px">* Mandatory fields are requested for express courrier proper delivery (in three to five working days).<br>
<br>
<em>* Tous les champs doivent &ecirc;tre remplis pour assurer la livraison rapide de votre commande (en trois &agrave; cinq jours ouvrables) </em></td></tr>
</table>
  <br>
  <div align="center">
  <input name="txtAmount" type="hidden" value="<?php echo $total;?>">
  <input name="txtCurrency" type="hidden" value="840">
  <input name="txtIndex" type="hidden" value="95">
  <input name="txtMerchNum" type="hidden" value="04024601">
  <input name="txthttp" type="hidden" value="http://www.pascalbeaudenon.com/confirmation.php">
  
	<input name="tol" type="hidden" value="<?php echo $tol;?>">
	<input name="calendar2006" type="hidden" value="<?php echo $calendar2006;?>">
	<input name="calendar2007" type="hidden" value="<?php echo $calendar2007;?>">
	<input name="calendar2008" type="hidden" value="<?php echo $calendar2008;?>">
	<input name="calendar2009" type="hidden" value="<?php echo $calendar2009;?>">
	<input name="postcards1" type="hidden" value="<?php echo $postcards1;?>">
		<input name="postcards2" type="hidden" value="<?php echo $postcards2;?>">
	<input name="post2_eng" type="hidden" value="<?php echo $post2_eng;?>">
	<input name="post2_eng" type="hidden" value="<?php echo $post2_eng;?>">
	
	<input name="book_01_eng" type="hidden" value="<?php echo $book_01_eng;?>">
	<input name="book_01_fr" type="hidden" value="<?php echo $book_01_fr;?>">
	<input name="calendar2009_fr" type="hidden" value="<?php echo $calendar2009_fr;?>">
	<input name="calendar2009_eng" type="hidden" value="<?php echo $calendar2009_eng;?>">
	<input name="calendar2006_eng" type="hidden" value="<?php echo $calendar2006_eng;?>">
	<input name="calendar2006_fr" type="hidden" value="<?php echo $calendar2006_fr;?>">
	<input name="post1_eng" type="hidden" value="<?php echo $post1_eng;?>">
	<input name="post1_fr" type="hidden" value="<?php echo $post1_fr;?>">
	<input name="post2_fr" type="hidden" value="<?php echo $post2_fr;?>">
	
	<input name="datenow" type="hidden" value="<?php echo date("d/m/Y"); ?>">
  <br>
    <input type="submit" name="Submit" value="Continue"></div>
</form>

<table width="100" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="http://www.netcommerce.com.lb/logo/epayment-netcommerce.gif" width="400"
height="38" border="0" alt="E-Payment By Netcommerce"><br><br></td>
  </tr>
</table>
<table width="650" height="1" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td style="background:#cccccc;"><img src="pics/pixel.gif" width="1" height="1"></td>
  </tr>
</table>
<table width="651" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="380" class="t10">&copy; pascal beaudenon, 2005</td>
    <td width="271" align="right" class="t10">&nbsp;</td>
  </tr>
</table>
<br>
<br>
</body>
</html>
